# Cours Redux

** INSTALLER REDUX **
npm i -s redux react-redux @reduxjs/toolkit @redux-devtools/extension
Télécharger Redux DevTools

1- Provider qui englobe l'app
2- Création store
3- Création reducers
4- Création actions

** JSON-SERVER **
npm i -g json-server
"json-server --w db.json" || "npm run server"
